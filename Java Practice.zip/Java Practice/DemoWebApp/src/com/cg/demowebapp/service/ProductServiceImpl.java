package com.cg.demowebapp.service;

import java.util.List;

import com.cg.demowebapp.dao.ProductDao;
import com.cg.demowebapp.dao.ProductDaoImpl;
import com.cg.demowebapp.dto.Product;

public class ProductServiceImpl implements  ProductService{
		ProductDao dao;
		public ProductServiceImpl() {
			dao=new ProductDaoImpl();
			}
	@Override
	public void addProduct(Product prod) {
		// TODO Auto-generated method stub
		dao.save(prod);
	}

	@Override
	public List<Product> showProduct() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}
		
}
