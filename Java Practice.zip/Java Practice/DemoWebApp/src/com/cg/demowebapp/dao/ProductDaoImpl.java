package com.cg.demowebapp.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapp.dto.Product;

public class ProductDaoImpl implements ProductDao {
		List<Product> myList=new LinkedList<>();
	@Override
	public void save(Product prod) {
		// TODO Auto-generated method stub
		myList.add(prod);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return myList;
	}

}
