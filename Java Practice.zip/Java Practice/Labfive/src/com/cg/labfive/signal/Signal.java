package com.cg.labfive.signal;

public class Signal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
