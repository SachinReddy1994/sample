package com.cg.sampleproject;

import java.util.List;
import java.util.Scanner;

import com.cg.sampleproject.dto.Employee;
import com.cg.sampleproject.exception.EmployeeException;
import com.cg.sampleproject.service.EmployeeService;
import com.cg.sampleproject.service.EmployeeServiceImp;

public class SampleProject {
	static EmployeeService service;
	public SampleProject() {
						}
	public static void main(String[] args) {
			Scanner sc= new Scanner(System.in);
			service = new EmployeeServiceImp();
			int choice=0;
			do {
				printDetails();
				System.out.println("Enter the Choice : ");
				choice=sc.nextInt();
				switch(choice) {
				case 1 : System.out.println("Enter the Employee Id : ");
						int id = sc.nextInt();
						 System.out.println("Enter the Employee Name : ");
						String name = sc.next(); 
						 System.out.println("Enter the Employee Salary : ");
						double salary = sc.nextDouble();
						
						Employee emp = new Employee();
						emp.setId(id);
						emp.setName(name);
						emp.setSalary(salary);
						
						service.addEmployee(emp);
						break;
				case 2 : 
					List<Employee> myList = service.showAll();		
					for (Employee empData : myList) {
						System.out.println("Id is : "+empData.getId());
						System.out.println("Name is : "+empData.getName());
						System.out.println("Salary is : "+empData.getSalary());
					}	
					break ; 
				case 3 : System.out.println("Enter the Employee Id : ");
						int sid = sc.nextInt();
					try {
						Employee empSearch = service.searchbyId(sid);
						if(empSearch!=null)
						System.out.println(empSearch);
					} catch (EmployeeException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				case 4 : 
					System.out.println("Etner the Employee to search Name : ");
					String sname = sc.next();
					List<Employee> empSearch = service.searchbyName(sname);
					for (Employee empAll : empSearch) {
						System.out.println("Id is : "+empAll.getId());
					}
						break;	
				}
			}while(choice!=6);
	}
	
					public static void printDetails() {
						System.out.println("1.Add Employee : ");
						System.out.println("2.Show All Employee : ");
						System.out.println("3.Update Employee : ");
						System.out.println("4.Search Employee By Name : ");
						System.out.println("5.Sort : ");
	}
}
