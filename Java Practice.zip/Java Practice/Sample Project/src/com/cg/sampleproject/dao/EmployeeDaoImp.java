package com.cg.sampleproject.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.sampleproject.dto.Employee;
import com.cg.sampleproject.exception.EmployeeException;

public class EmployeeDaoImp implements EmployeeDao{
	List<Employee> empData;
	public EmployeeDaoImp() {
			empData = new ArrayList<Employee>();
	}

	@Override
	public Employee save(Employee emp) {
		empData.add(emp);
		 return emp;
	}

	@Override
	public List<Employee> findBy(String Name) {
		List<Employee> empSearch = new ArrayList();
		for (Employee employee : empData) {
			if(employee.getName().equals(Name)) {
				empSearch.add(employee);
			}
		}
		return empSearch;
	}

	@Override
	public Employee findbyId(int id) throws EmployeeException{
			for (Employee employee : empData) {
					if(employee.getId()==id) {
						return employee;
			}
					else {
						throw new EmployeeException("Id not Found");
					}
			}
			return null;
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return empData;
	}

}
