package com.cg.sampleproject.dao;

import java.util.List;

import com.cg.sampleproject.dto.Employee;
import com.cg.sampleproject.exception.EmployeeException;

public interface EmployeeDao {
		public Employee save(Employee emp);
		public List<Employee> findBy(String Name);
		public Employee findbyId(int id) throws EmployeeException;
		public List<Employee> showAll();
}
