package com.cg.sampleproject.service;

import java.util.List;

import com.cg.sampleproject.dao.EmployeeDao;
import com.cg.sampleproject.dao.EmployeeDaoImp;
import com.cg.sampleproject.dto.Employee;
import com.cg.sampleproject.exception.EmployeeException;

public class EmployeeServiceImp implements EmployeeService{
			EmployeeDao dao;
	public EmployeeServiceImp() {
		dao= new EmployeeDaoImp();
	}
	
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		emp.setSalary(emp.getSalary()+(emp.getSalary()*10/100));
		dao.save(emp);
	}
	
	@Override
	public List<Employee> searchbyName(String name) {
		// TODO Auto-generated method stub
		return dao.findBy(name);
	}

	@Override
	public Employee searchbyId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.findbyId(id);
	}

	@Override
	public List<Employee> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	@Override
	public Employee update(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		
	}

}
