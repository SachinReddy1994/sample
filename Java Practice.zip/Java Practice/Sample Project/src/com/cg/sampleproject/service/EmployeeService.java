 package com.cg.sampleproject.service;

import java.util.List;

import com.cg.sampleproject.dto.Employee;
import com.cg.sampleproject.exception.EmployeeException;

public interface EmployeeService {
		public void addEmployee(Employee emp);
		public List<Employee> searchbyName(String name);
		public Employee searchbyId(int id) throws EmployeeException;
		public List<Employee> showAll();
		public Employee update(Employee emp);
		public void sort();
}
