package testconnectin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {
		static final String url = "jdbc:mysql://localhost:3306/world";
		static final String user = "root";
		static final String password = "Capgemini123";
	public static void main(String[] args) {
		try {
			Connection con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Connection Establsihed Successfully");
	}

}
