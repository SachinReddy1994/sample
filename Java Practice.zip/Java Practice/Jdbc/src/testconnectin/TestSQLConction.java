package testconnectin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestSQLConction {
	
	public static void main(String[] args) throws SQLException {
			Connection con = null;
			try {
	//			con = DriverManager.getConnection(url, user, password);
				con = DbUtil.getConnection(DbType.MYSQLDB);
				System.out.println("Connection Established Successsfully");
			} catch (SQLException e) {
				System.out.println(e.getMessage());
		}finally {
			con.close();
		}
	}
}
