package testconnectin;

public enum DbType {
		 MYSQLDB
}
