package testconnectin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	private static final String user = "root";
	private static final String password = "Capgemini123";
	private static final String url = "jdbc:mysql://localhost:3306/world";
	
	public static Connection getConnection(DbType dbType) throws SQLException {
		switch(dbType) {
		case MYSQLDB : return DriverManager.getConnection(url, user, password);
		
		default : 
			return null;
		}
	}
}
