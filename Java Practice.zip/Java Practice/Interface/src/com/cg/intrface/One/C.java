package com.cg.intrface.One;

public class C {

			public static void main(String[] args) {
				A temp = new B();
				temp.getDefaultAll();
				B.getStaticAll();
			}
}
