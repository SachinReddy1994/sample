package com.cg.intrface.One;

public class B implements A {

	@Override
	public void getAllData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAllData() {
		// TODO Auto-generated method stub
		
	}
		
	static void getStaticAll() {
		String name = "Cap";
		System.out.println("In...B  .Static");
	}
	
	}
