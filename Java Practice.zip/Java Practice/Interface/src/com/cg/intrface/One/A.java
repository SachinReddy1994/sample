package com.cg.intrface.One;

public interface A {
		public void getAllData();
		public void printAllData();

		static void getStaticAll() {
			String name = "Cap";
			System.out.println("In....Static");
		}
		default void getDefaultAll() {
			String name = "Cap";
			System.out.println("In....Default");
		}
}
