package com.cg.intrface.One;

public class Intrfaces implements A,B,C{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void getAllData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAllData() {
		// TODO Auto-generated method stub
		
	}


	
	@Override
	public void getMyName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

}
