package com.cg.intrface.ui;

public class Intrface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Timing temp =  new DayShift(); // this is runtime polymorphism concept
			System.out.println(temp.time);
			temp.getLogin();
			temp.getLogout();
			temp.getCompany();
	}

}
