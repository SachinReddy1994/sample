package com.cg.intrface.ui;

public class DayShift implements Timing{

	@Override
	public void getLogin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getLogout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getCompany() {
		// TODO Auto-generated method stub
		
	}

}
