package com.cg.intrface.ui;

public interface Timing {
			double time = 9.5; // in Interface Compiler treats these as static or final
			public void getLogin(); // In Interface class every method is abstract only 
			public void getLogout();
			public void getCompany();
}
