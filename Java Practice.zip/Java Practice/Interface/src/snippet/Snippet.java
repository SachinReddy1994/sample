package snippet;

public class Snippet {
	public void getAll() {
			 System.out.println("Hi A ...");
}
}

