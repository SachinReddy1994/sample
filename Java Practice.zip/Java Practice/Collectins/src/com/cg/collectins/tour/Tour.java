package com.cg.collectins.tour;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

public class Tour {
	public static void main(String[] args) {
/*		System.out.println("Puen Flight time : ");
		LocalTime time = LocalTime.now();
		Date today = new Date();
		
		System.out.println(time.plusHours(7));
		System.out.println(today);
		//LocalTime newYork;
		ZonedDateTime nyZone = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
		//System.out.println(newYork = time.plusHours(26));
		System.out.println(nyZone.plusHours(26));
		*/
	
	
	}
}
