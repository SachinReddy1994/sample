package com.cg.collectins;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		
		List<String> myList = new LinkedList<String>();
		myList.add("A");
		myList.add("C");
		myList.add("F");
		myList.add("A");
		System.out.println(myList.get(3));
		System.out.println(myList.set(0, "U"));
		System.out.println(myList);
		
	}		
}		
		// TODO Auto-generated method stub
			/*List<String> myLst = new LinkedList<String>();
			myLst.add("S");
			myLst.add("C");
			myLst.add("A");
			System.out.println(myLst);
			for(String list:myLst) {
				System.out.println(list);
			}
			System.out.println("-------------");
			*/
		/*Integer a=10;
		Integer b=10;
		System.out.println(a.hashCode());
		System.out.println(b.hashCode());
		System.out.println(a.equals(b));
		System.out.println(a==b);
		Employee emp = new Employee(10);
		Employee empOne = new Employee(200);
		//emp=empOne;
		System.out.println(empOne.hashCode());
		System.out.println(emp.hashCode());
		System.out.println(emp.equals(empOne));
	}
	}

final class Employee{
	 public Employee(int i) {
		// TODO Auto-generated constructor stub
	}

	int id;
}
*/