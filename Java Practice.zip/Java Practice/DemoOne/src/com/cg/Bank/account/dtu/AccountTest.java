package com.cg.Bank.account.dtu;
import static org.junit.Assert.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccountTest {
	Account acc;

	@BeforeEach
public void doBeforeMyTest() {
				 Account acc = new Account();
	}
	@Test
	void doMyTest() {
		
				assertEquals();
	}
	private void assertEquals() {
		// TODO Auto-generated method stub
		
	}
	@Test
	void doMyTestOne() {
			System.out.println("In Test.1...");
			}
	@Test
	
	void doMyTestTw0() {
			System.out.println("In Test..2..");
	}
	@Test
	void doMyTestThree() {
			System.out.println("In Test..3..");
	}
     @AfterEach
     public void doAfterTest() {
    	 System.out.println("After Test....");
     }
}
