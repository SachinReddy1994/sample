package com.cg.Bank.account.dtu;

public class Account {
	private int accountNo;
	private double acntBalance;
	public Account(int accountNo, double acntBalance) {
		super();
		this.accountNo = accountNo;
		this.acntBalance = acntBalance;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public double getAcntBalance() {
		return acntBalance;
	}
	public void setAcntBalance(double acntBalance) {
		this.acntBalance = acntBalance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", acntBalance=" + acntBalance + "]";
	}
	
	
}
