package com.cg.Bank.ui;

import java.util.Scanner;

import com.cg.Bank.account.dtu.Account;
import com.cg.Bank.user.dtu.User;

public class Bank {
	public static void main(String[] args) {
		User use = new User();
		Account acnt = new Account();
		int option = 0;
		Scanner sc=new Scanner(System.in);
		do 
		{ 
			System.out.println("1.Add\n 2.Exit");
			System.out.println("Enter Choice : ");
			option = sc.nextInt();
			sc.nextLine();
			switch(option) {
			case 1 : System.out.println("Enter the User Name : ");
					 String Name = sc.nextLine();
					 System.out.println("Enter the User Id : ");
					 int id = sc.nextInt();
					 System.out.println("Enter the User Account Balance : ");
					 double balance = sc.nextDouble();
					 use.setUserName(Name);
					 use.setUserId(id);
					 acnt.setAcntBalance(balance);
					 use.setAcnt(acnt);
					 break;	 

			case 2 :  System.out.println("Id : "+use.getUserId());
					  System.out.println("Name : " +use.getUserName());
					  System.out.println("Account Balance : " +use.getAcnt().getAcntBalance());
					  option=0;
			break;
			default : System.out.println("Invalid Choice");
			break;
			}
		}while(option!=0);
	}

}
