package com.cg.MavenDemoTwo.junitTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MyApplicationTest {
	@BeforeEach
	void beforeEach(){
		System.out.println("IN Before...");
	}
	@Test
	void test() {
		System.out.println("n Test....");
	}
	@AfterEach
	void afterEach(){
		System.out.println("IN After...");
	}
}
