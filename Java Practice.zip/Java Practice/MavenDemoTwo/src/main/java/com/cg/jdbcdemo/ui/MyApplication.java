package com.cg.jdbcdemo.ui;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MyApplication {

	public static void main(String[] args) {

		InputStream in=null;
		Scanner sc=new Scanner(System.in);
		int id;
		double salary;
		String name;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			in=new FileInputStream("src/main/resources/jdbc.properties");
			Properties prop=new Properties();

			prop.load(in);
			Class.forName(prop.getProperty("jdbc.driver"));
			con=DriverManager.getConnection(prop.getProperty("jdbc.url"), prop.getProperty("jdbc.username"), prop.getProperty("jdbc.password"));
			if(con!=null)
				System.out.println("Database connected...");
			System.out.println("Enter id: ");
			id=sc.nextInt();
			System.out.println("Enter Name: ");
			name=sc.next();
			System.out.println("Enter salary: ");
			salary=sc.nextDouble();
			ps=con.prepareStatement("insert into Employee values(?,?,?)");
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			int count=ps.executeUpdate();
			if(count==1)
				System.out.println("Record inserted...");
			ps=con.prepareStatement("SELECT * FROM EMPLOYEE");
			rs=ps.executeQuery();
			while(rs.next())
				System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getDouble("emp_salary"));

			ps=con.prepareStatement("UPDATE EMPLOYEE SET emp_salary=? WHERE emp_id=?");
			System.out.println();
			System.out.println("****************Update salary****************");
			System.out.println("Enter empid: ");
			id=sc.nextInt();
			System.out.println("Enter salary: ");
			salary=sc.nextDouble();
			ps.setInt(2, id);
			ps.setDouble(1, salary);
			int i=ps.executeUpdate();
			if(i==1)
				System.out.println("Record updated...");

			System.out.println();
			System.out.println("************Delete record*********");
			System.out.println("enter id: ");
			id=sc.nextInt();
			ps=con.prepareStatement("delete from employee where emp_id=?");
			ps.setInt(1,id);
			ps.executeUpdate();
			System.out.println("record deleted");
			System.out.println();

			ps=con.prepareStatement("SELECT * FROM EMPLOYEE");
			rs=ps.executeQuery();
			while(rs.next())
				System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getDouble("emp_salary"));

		}catch(ClassNotFoundException e) {
			System.out.println("Driver not loaded...");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(in!=null)
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
/*public class MyApplication {

	public static void main(String[] args) {
     
		Scanner sc=new Scanner(System.in);
		String driver=null,url=null,uname-null,upass=null;
		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Capgemini123");
			InputStream it = new FileInputStream("src/main/db.properties");
				 Properties prop = new Properties();
				    prop.load(it);
				    driver=prop.getProperty("jdbc.driver");
				    url=prop.getProperty("jdbc.url");
				    uname=prop.getProperty("jdbc.username");
				    upass=prop.getProperty("jdbc.password");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}      try {
		Class.forName();
	}
}*/

			//PreparedStatement pstm= conn.prepareStatement("delete from employee where id=emp_id");		
		
		/*PreparedStatement pstm= conn.prepareStatement("select * from employee");
		ResultSet result = pstm.executeQuery();
		while(result.next()) {
			int id = result.getInt("emp_id");
			String name = result.getString("emp_name");
			double salary = result.getDouble("emp_salary");	
			System.out.println(id+" "+name+"   "+salary);
		}*/
		//PreparedStatement pstm= conn.prepareStatement("INSERT INTO EMPLOYEE VALUES(?,?,?)");
		//PreparedStatement pstmOne= conn.prepareStatement("update employee  set emp_id=? where emp_salary=?");
		/*System.out.println("Enter id: ");
        int id=sc.nextInt();
        System.out.println("Enter name: ");
        String name=sc.next();
        System.out.println("Enter salary: ");
        double salary=sc.nextDouble();
        
        pstm.setInt(1, id);
		pstm.setString(2, name);
		pstm.setDouble(3, salary);
		

		?">,pstm.executeUpdate();
				System.out.println("Connection Established");
*/		 /*catch (ClassNotFoundException e) {
		System.out.println("Driver Not Loaded");
	} catch (SQLException e) {
			e.printStackTrace();
	}*/
		
