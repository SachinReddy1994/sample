package com.cg.demo.collection.dto;

import java.util.Comparator;

public class EmployeeSorting implements Comparator<Employee>{

	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
	/*	if(o1.getId()<o2.getId()) {
			return 1;
		}else if(o1.getId()>o2.getId()) {
			return -1;
		}else */
		return o1.getName().compareToIgnoreCase(o2.getName());
	}

}
