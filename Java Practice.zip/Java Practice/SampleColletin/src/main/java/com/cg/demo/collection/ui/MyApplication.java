package com.cg.demo.collection.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.cg.demo.collection.dto.Employee;
import com.cg.demo.collection.dto.EmployeeSorting;

public class MyApplication {

	public static void main(String[] args) {
		/* Employee emp = new Employee(10,"D",54541.54);
		 Employee empOne = new Employee(10,"D",54541.54);
		 Employee empTwo = new Employee(10,"D",54541.54);
		 Set<Employee> mySet = new HashSet<Employee>();
		 mySet.add(emp);
		 mySet.add(empOne);
		 mySet.add(empTwo);
		 List<Employee> myList=new ArrayList<Employee>(mySet);
		 Collections.sort(myList);
		 for(Employee employee : myList)
		 {
		 System.out.println(employee.getName());
		 }
		 System.out.println(mySet);
		*/
		/* Employee emp = new Employee(103,"Ds",5441.5);
		 Employee empOne = new Employee(100,"AD",651.54);
		 Employee empTwo = new Employee(102,"uD",659.54);
		 Set<Employee> mySet = new TreeSet<Employee>();
		 mySet.add(emp);
		 mySet.add(empOne);
		 mySet.add(empTwo);
		 System.out.println(mySet);*/
		
		 /*Employee<Integer,Double> emp = new Employee<Integer,Double>(105,"aD",554.05);
		 Employee<BigInteger,BigDecimal> empOne = new Employee<BigInteger,BigDecimal>
		 (new BigInteger("101"),"uD",new BigDecimal(189.55));
		 Employee empTwo = new Employee(100,"Db",854);
		 
		 List<Employee> myList=new ArrayList<Employee>();
		 
		 myList.add(emp);
		 myList.add(empOne);
		 myList.add(empTwo);
		Collections.sort(myList,new EmployeeSorting());
		 System.out.println(myList);*/
		
		
	/*	Map<Integer, String> myMap= new HashMap<Integer, String>();
		
		myMap.put(101, "Ady");
		myMap.put(100, "Danny");
		myMap.put(103, "Banny");
		*/
		// Integer i = new Integer(00001001);
		//int i =000000100;
		//System.out.println(i);
		Employee<Integer,Double> empOne = new Employee<Integer,Double>(1001,"DC",948.51);
		Employee<Integer,Double> empTwo = new Employee<Integer,Double>(109,"fA",485.51);
		Employee<Integer,Double> empThree = new Employee<Integer,Double>(559,"aB",748.51);
		Employee<Integer,Double> empFour = new Employee<Integer,Double>(1099,"sC",698.51);
		Map< Integer,Employee> myMap = new HashMap<Integer,Employee>();
		 
		myMap.put(1,empOne);
		myMap.put(2,empTwo);
		myMap.put(3,empThree);
		myMap.put(4,empFour);
		
		Collection<Employee> myCollection = myMap.values();
		List<Employee> empList =  new ArrayList<Employee>(myCollection);
		Collections.sort(empList, new EmployeeSorting());
				for (Employee employee2 : empList) {
					System.out.println("Name is :" +employee2.getName());
				}
		
		
		//Set<Entry<Employee,Integer>> set = myMap.entrySet();
		/*Map<Employee, Integer> treeMap = new TreeMap<Employee, Integer>(myMap);
		
		for (Employee str : treeMap.keySet()) {
		    System.out.println(str);
		}*/
		//for(Integer it : myMap.keySet()) {
			//System.out.println(myMap.keySet());
		//}
	}
}
