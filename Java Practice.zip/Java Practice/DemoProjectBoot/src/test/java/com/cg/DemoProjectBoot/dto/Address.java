package com.cg.DemoProjectBoot.dto;

public class Address {

}
