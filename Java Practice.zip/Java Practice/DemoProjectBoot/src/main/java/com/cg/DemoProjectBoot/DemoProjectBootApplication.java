package com.cg.DemoProjectBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.DemoProjectBoot")
public class DemoProjectBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectBootApplication.class, args);
		System.out.println("Welcome to spring boot");
	}

}
