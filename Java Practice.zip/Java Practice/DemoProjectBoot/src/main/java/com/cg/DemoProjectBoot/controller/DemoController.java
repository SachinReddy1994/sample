package com.cg.DemoProjectBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.DemoProjectBoot.dto.Vendor;
import com.cg.DemoProjectBoot.service.VendorService;

@RestController
@RequestMapping("/curry")
public class DemoController {
	@Autowired
	VendorService vendorService;
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Vendor> addVendor(@ModelAttribute Vendor vendo){
		Vendor vendor=vendorService.addVendor(vendo);
		if(vendor==null) {
			return new ResponseEntity(" No Vendor added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Vendor>(vendor,HttpStatus.OK);
	}
	
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ResponseEntity<List<Vendor>> search(@RequestParam("pname") String name){
		List<Vendor> vendorList=vendorService.findByName(name);
		if(vendorList.isEmpty()) {
			return new ResponseEntity("Np Vendor to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Vendor>>(vendorList,HttpStatus.OK);
}	
	@RequestMapping(value="/searchby",method=RequestMethod.GET)
	public ResponseEntity<List<Vendor>> searchCity(@RequestParam("pcity") String city){
		List<Vendor> vendorList=vendorService.searchByCity(city);
		if(vendorList.isEmpty()) {
			return new ResponseEntity("Np Vendor to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Vendor>>(vendorList,HttpStatus.OK);
}
}