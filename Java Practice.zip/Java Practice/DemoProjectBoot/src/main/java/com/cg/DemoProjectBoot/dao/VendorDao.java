package com.cg.DemoProjectBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.DemoProjectBoot.dto.Vendor;

public interface VendorDao extends JpaRepository<Vendor, Integer> {
	@Query("SELECT v FROM Vendor v, IN(v.address) a WHERE a.city= :city")
	public List<Vendor> findByCity(@Param("city") String city);
	//@Query("SELECT v FROM Vendor v WHERE v.name= :name")
	public List<Vendor> findByName(String name);
}
