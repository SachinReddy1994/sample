package com.cg.DemoProjectBoot.service;

import java.util.List;

import com.cg.DemoProjectBoot.dto.Vendor;

public interface VendorService {
	public Vendor addVendor(Vendor vendor);
	public List<Vendor> searchByCity(String city);
	public List<Vendor> findByName(String name);
}
