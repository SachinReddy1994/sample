package com.cg.DemoProjectBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.DemoProjectBoot.dao.VendorDao;
import com.cg.DemoProjectBoot.dto.Item;
import com.cg.DemoProjectBoot.dto.Vendor;

@Service
public class VendorServiceImpl implements VendorService{
		@Autowired
	VendorDao vendorDao;
		static int id=100;
		static int addressId=10;
		static int itemId=200;
	@Override
	public Vendor addVendor(Vendor vendor) {
		// TODO Auto-generated method stub
		vendor.setId(id);
		vendor.getAddress().setId(addressId);
		for(Item item: vendor.getItems()){
			item.setId(itemId);
			itemId++;
		}
		addressId++;
		id++;
		return vendorDao.save(vendor);
	}
	@Override
	public List<Vendor> findByName(String name) {
		// TODO Auto-generated method stub
		return vendorDao.findByName(name);
	}
	@Override
	public List<Vendor> searchByCity(String city) {
		// TODO Auto-generated method stub
		return vendorDao.findByCity(city);
	}

}
