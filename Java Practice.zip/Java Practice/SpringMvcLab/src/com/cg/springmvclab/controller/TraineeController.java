package com.cg.springmvclab.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.springmvclab.dto.Trainee;
import com.cg.springmvclab.service.TraineeService;

@Controller
public class TraineeController {
	 @Autowired
	 TraineeService traineeService;
	@GetMapping("login")
	public String loginPage() {
		return "adminlogin";
	}
	
	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String admin,@RequestParam("upass") String password){
		if(admin.equals("admin") && password.equals("123456")) {
			return "traineeManagement";
		}else
			return "error";
	}
	@GetMapping("add")
	public ModelAndView getAddTrainee(@ModelAttribute("tran") Trainee traine) {
		List<String> listofDomain=new ArrayList<String>();
		listofDomain.add("Java");
		listofDomain.add(".Net");
		listofDomain.add("Python");
		listofDomain.add("BigData");
		listofDomain.add("Machine Learning");
		return new ModelAndView("addTrainee","dom",listofDomain);
	}
	
	@GetMapping("showall")
	public ModelAndView showAllTrainee() {
		List<Trainee> myAllTrainee=traineeService.showAll();
		return new ModelAndView("retrieveall", "showtrainee", myAllTrainee);
	}
	
	@PostMapping("addTrainee")
	public ModelAndView addTrainee(@ModelAttribute("tran") Trainee traine) {
		Trainee trane=traineeService.addTrainee(traine);
		return new ModelAndView("traineeManagement","trn",trane);
		
	}
	
	@GetMapping("show")
	public ModelAndView showTrainee(@ModelAttribute("tran") Trainee traine) {
		Trainee traneOne=traineeService.searchTraineById(traine.getTraineeId());
		return new ModelAndView("searchTrainee","tran",traneOne);
	}
	
	@GetMapping("modify")
	public String ModifyTrainee() {
		return "modify";
	}
	
	@GetMapping("delete")
	public String deleteTrainee() {
		return "remove";
}
}