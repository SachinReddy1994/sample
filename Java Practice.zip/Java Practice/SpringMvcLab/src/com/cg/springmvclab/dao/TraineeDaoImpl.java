package com.cg.springmvclab.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cg.springmvclab.dto.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao{
   List<Trainee> myList=new ArrayList<Trainee>();
	@Override
	public Trainee save(Trainee traine) {
		// TODO Auto-generated method stub
		 myList.add(traine);
		 return traine;
	}

	@Override
	public List<Trainee> show() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Trainee findTraineeById(Integer id) {
		for (Trainee trainee : myList) {
			if(trainee.getTraineeId()==id) {
				return trainee;
			}
		}
		return null;
	}

	@Override
	public Trainee delete(Integer id) {
		Trainee trainee = findTraineeById(id);
		myList.remove(trainee);
		return null;
	}
}