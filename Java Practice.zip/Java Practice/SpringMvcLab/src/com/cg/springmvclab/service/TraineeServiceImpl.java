package com.cg.springmvclab.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springmvclab.dao.TraineeDao;
import com.cg.springmvclab.dto.Trainee;

@Service
public class TraineeServiceImpl implements TraineeService{
	 @Autowired
	 TraineeDao traineeDao;
	@Override
	public Trainee addTrainee(Trainee traine) {
		// TODO Auto-generated method stub
		return traineeDao.save(traine);
	}

	@Override
	public List<Trainee> showAll() {
		// TODO Auto-generated method stub
		return traineeDao.show();
	}
	
	@Override
	public Trainee searchTraineById(Integer id) {
		return traineeDao.findTraineeById(id);
	}
	
	@Override
	public Trainee deleteTrainee(Integer id) {
		return traineeDao.delete(id);
	}
}
