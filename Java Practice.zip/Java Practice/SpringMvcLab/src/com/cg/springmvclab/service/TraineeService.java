package com.cg.springmvclab.service;

import java.util.List;

import com.cg.springmvclab.dto.Trainee;

public interface TraineeService {
	public Trainee addTrainee(Trainee traine);
	public List<Trainee> showAll();
	public Trainee searchTraineById(Integer id);
	public Trainee deleteTrainee(Integer id);
	
}
