package com.cg.productapp.service;

import java.util.List;

import com.cg.productapp.dto.Product;
import com.cg.productapp.exception.ProductException;



public interface ProductService {

	public Product add(Product pro); 
	public List<Product> show();
	public Product searchById(int id) throws ProductException;
	public List<Product> searchByPriceLimit(double low,double up) throws ProductException;
	public Product update(Product pro) throws ProductException;
	public List<Product> sortById(int id);
	public void delete(Product pro);
}

