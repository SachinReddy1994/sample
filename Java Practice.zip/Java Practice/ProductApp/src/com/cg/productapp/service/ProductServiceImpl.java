package com.cg.productapp.service;

import java.util.List;

import com.cg.productapp.dao.ProductDao;
import com.cg.productapp.dao.ProductDaoImpl;
import com.cg.productapp.dto.Product;
import com.cg.productapp.exception.ProductException;


public class ProductServiceImpl implements ProductService{
	ProductDao dao;
	public ProductServiceImpl() {
		dao= new ProductDaoImpl();
	}
	@Override
	public Product add(Product pro) {
		// TODO Auto-generated method stub
		return dao.save(pro);
	}
	@Override
	public List<Product> show() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}
	@Override
	public Product searchById(int id) throws ProductException {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public Product update(Product pro) throws ProductException {
		// TODO Auto-generated method stub
		Product pr=dao.findById(pro.getId());
		if(pro!=null) {
			pr.setPrice(pro.getPrice());
		}
		
		return pr;
	}
	@Override
	public void delete(Product pro) {
		// TODO Auto-generated method stub
		dao.delete(pro);
		
	}
	@Override
	public List<Product> searchByPriceLimit(double low, double up) throws ProductException {
		// TODO Auto-generated method stub
		return dao.findByPriceLimit(low, up);
	}
	@Override
	public List<Product> sortById(int id) {
		// TODO Auto-generated method stub
		return dao.sortById(id);
	}

}
