package com.cg.productapp.ui;
import com.cg.productapp.exception.ProductException;
import com.cg.productapp.service.ProductService;
import com.cg.productapp.service.ProductServiceImpl;
import java.util.List;
import java.util.Scanner;
import com.cg.productapp.dto.Product;

public class MyApplication {
static ProductService service;
	
	public static void main(String[] args) {
		service=new ProductServiceImpl();
		Scanner sc=new Scanner(System.in);
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter choice: ");
			choice=sc.nextInt();
			switch(choice) {
			case 1: System.out.println("Enter Product ID: ");
					int id=sc.nextInt();
					sc.nextLine();
					System.out.println("Enter Product Name: ");
					String name=sc.nextLine();
					System.out.println("Enter Price: ");
					double price=sc.nextDouble();
					sc.nextLine();
					System.out.println("Enter Product Description: ");
					String des=sc.nextLine();
					Product pro=new Product();
					pro.setId(id);
					pro.setName(name);
					pro.setPrice(price);
					pro.setDescription(des);
					service.add(pro);
					break;
			case 2: List<Product> myList=service.show();
					for (Product proData : myList) {
						System.out.println("ID: "+proData.getId());
						System.out.println("Name: "+proData.getName());
						System.out.println("Price: "+proData.getPrice());
						System.out.println("Descriptiom: "+proData.getDescription());
					}
					break;
			case 3: sc.nextLine();
					System.out.println("Enter id : ");
				
					try {
					Product proSearch=service.searchById((sc.nextInt()));
					if(proSearch!=null) {
					System.out.println("Enter Price to be updated: ");
					proSearch.setPrice(sc.nextDouble());
					proSearch=service.update(proSearch);
					System.out.println("ID: "+proSearch.getId());
					System.out.println("Name: "+proSearch.getName());
					System.out.println("Price: "+proSearch.getPrice());
					System.out.println("Descriptiom: "+proSearch.getDescription());
					}
					}
					catch(ProductException e) {
						System.out.println(e.getMessage());
					}
					break;
					
			case 4: sc.nextLine();
					System.out.println("Enter the lower limit: ");
					double low=sc.nextDouble();
					System.out.println("Enter the upper limit: ");
					double up=sc.nextDouble();
					List<Product> myListOne;
					try {
					
						myListOne = service.searchByPriceLimit(low, up);
						if(!myListOne.isEmpty()) {
						for (Product proData : myListOne) {
						System.out.println("ID: "+proData.getId());
						System.out.println("Name: "+proData.getName());
						System.out.println("Price: "+proData.getPrice());
						System.out.println("Descripton: "+proData.getDescription());
						}
						}
					}catch (ProductException e) {
						System.out.println(e.getMessage());
					}
					break;
			case 5: System.out.println("Enter id : ");
					try {
						
						Product proSearch=service.searchById((sc.nextInt()));
						if(proSearch!=null) {
							System.out.println("ID: "+proSearch.getId());
							System.out.println("Name: "+proSearch.getName());
							System.out.println("Price: "+proSearch.getPrice());
							System.out.println("Descripton: "+proSearch.getDescription());
						}
						
					}catch(ProductException e){
						System.out.println(e.getMessage());
					}
					break;
			case 6: System.out.println("Enter id : ");
					try {
						Product proSearch=service.searchById((sc.nextInt()));
						if(proSearch!=null) {
							service.delete(proSearch);
							System.out.println("Deleted successfully!");
						}
					}catch(ProductException e) {
						System.out.println(e.getMessage());
					}
					break;
			
			case 8 : System.out.println("Sorting by Id's : ");
			
			
			}
		}while(choice!=8);
		sc.close();
				
	}
	public static void printDetails() {
		
		System.out.println("1. Add Product");
		System.out.println("2. Show All Products");
		System.out.println("3. Update Product");
		System.out.println("4. Search By Price range");
		System.out.println("5. Search By Id");
		System.out.println("6. Delete Product");
		System.out.println("7.Sort byId : ");
		System.out.println("8. Exit");
	}
}