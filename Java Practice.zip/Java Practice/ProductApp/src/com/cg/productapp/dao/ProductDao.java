package com.cg.productapp.dao;

import java.util.List;

import com.cg.productapp.dto.Product;
import com.cg.productapp.exception.ProductException;


public interface ProductDao {

	public Product save(Product pro);
	public void delete(Product pro);
	public Product findById(int id) throws ProductException;
	public List<Product> findByPriceLimit(double low,double up) throws ProductException;
	public List<Product> showAll();
	public List<Product> sortById(int id);
}
