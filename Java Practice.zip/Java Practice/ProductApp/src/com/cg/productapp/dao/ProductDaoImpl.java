package com.cg.productapp.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.productapp.dto.Product;
import com.cg.productapp.exception.ProductException;

public class ProductDaoImpl implements ProductDao{
	List<Product> proData;
	public ProductDaoImpl() {
		proData=new ArrayList<>();
	}
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		proData.add(pro);
		return pro;
	}

	@Override
	public void delete(Product pro) {
		proData.remove(pro);
		
	}

	@Override
	public Product findById(int id) throws ProductException {
		// TODO Auto-generated method stub
		for (Product product : proData) {
			if(product.getId()==id)
				return product;
		}
		throw new ProductException("Id not found!");
	}

	@Override
	public List<Product> findByPriceLimit(double low, double up) throws ProductException {
		List<Product> proSearch=new ArrayList<>();
		for (Product product : proData) {
			if((product.getPrice()>=low) && (product.getPrice()<=up))
				proSearch.add(product);
		}
		if(!proSearch.isEmpty())
			return proSearch;
		else
			throw new ProductException("No products found in the price range");
	}

	@Override
	public List<Product> showAll() {
	
		return proData;
	}
	@Override
	public List<Product> sortById(int id) {
		// TODO Auto-generated method stub
		Set<Product> mySet = new TreeSet<Product>();;
		return proData;
	}
}