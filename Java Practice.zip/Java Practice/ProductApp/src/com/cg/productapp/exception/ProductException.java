package com.cg.productapp.exception;

public class ProductException extends Exception{
	public ProductException() {
		// TODO Auto-generated constructor stub
	}
	public ProductException(String s) {
		super(s);
	}
}

