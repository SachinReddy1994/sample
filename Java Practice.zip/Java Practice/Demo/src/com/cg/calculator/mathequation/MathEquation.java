package com.cg.calculator.mathequation;

public class MathEquation {

	public double leftVal;
	public double rightVal;
	public char opCode;
	public double result;
	
	public void execute() {
	   switch(opCode) {
	   case 'a' :
		   result = leftVal + rightVal;
		   break;
	   case 'e' :
		   result = leftVal + rightVal;
		   break;
	   case 'i' :
		   result = leftVal + rightVal;
		   break;
	   case 'o' :
		   result = leftVal + rightVal;
		   break;
	   case 'u' :
		   result = leftVal + rightVal;
		   break;
	   default :  System.out.println("Error - Invalid Opcode");
	       result = 0.0d;
	       break;
	   }
	}
}
