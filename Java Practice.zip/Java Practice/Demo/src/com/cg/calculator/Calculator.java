package com.cg.calculator;

import com.cg.calculator.mathequation.MathEquation;

public class Calculator {

	public static void main(String[] args) {
          /*  double[] leftVals = {100.d,51.d,79.d,27.d,101.d};
            double[] rightVals = {12.d,9.d,7.d,3.d,21.d};
            char[] opCodes = {'a','e','i','o','u'};
            double[] results = new double[opCodes.length];*/
	
		MathEquation[] equations = new MathEquation[5];
		equations[0] = new MathEquation();
		  
         
	}
}
