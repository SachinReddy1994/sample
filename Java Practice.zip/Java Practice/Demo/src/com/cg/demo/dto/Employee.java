package com.cg.demo.dto;

import com.cg.Demoone.project.Project;

public class Employee {
	
	int empId;
	private String empName;
	private double salary;
	private String empDesg;
	private boolean bool;
	private char c;
	private Project prj;

	
	 public Employee(int empId, String empName, double salary, String empDesg, boolean bool, char c, Project prj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.empDesg = empDesg;
		this.bool = bool;
		this.c = c;
		this.prj = prj;
	}


	public Employee() {
		// TODO Auto-generated constructor stub
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public String getEmpDesg() {
		return empDesg;
	}


	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}


	public boolean isBool() {
		return bool;
	}


	public void setBool(boolean bool) {
		this.bool = bool;
	}


	public char getC() {
		return c;
	}


	public void setC(char c) {
		this.c = c;
	}


	public Project getPrj() {
		return prj;
	}


	public void setPrj(Project prj) {
		this.prj = prj;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", empDesg=" + empDesg
				+ ", bool=" + bool + ", c=" + c + ", prj=" + prj + "]";
	}


	
	}


