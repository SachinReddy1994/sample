package com.cg.demo.ui;

import java.util.Scanner;

//import com.cg.Demo.dto.*;
import com.cg.Demoone.project.Project;
import com.cg.demo.dto.Employee;

public class Firstapp {
	public static void main(String[] args) {
	
	Employee emp= new Employee();
	Project prj= new Project();
	/*int id=Integer.parseInt(args[0]);
	String name=args[1];
	double salary=Double.parseDouble(args[2]);
	String designation=args[3];
	
	int projId=Integer.parseInt(args[4]);
	String projName=args[5];
	double projPrice=Double.parseDouble(args[6]);
	String projDescription=args[7];
*/	
	Scanner scr=new Scanner(System.in);
	System.out.println("Enter the name : ");
	String name=scr.next();
	System.out.println("Enter the Employee Id");
	int id=scr.nextInt();
	
	System.out.println("Enter the salary : ");
	Double salary= scr.nextDouble();
	System.out.println("Enter the Designation");
	String designation=scr.next();
	
	System.out.println("Enter the Project Id");
	int projId=scr.nextInt();
	System.out.println("Enter theProject  name : ");
	String projName=scr.next();
	System.out.println("Enter the Price : ");
	Double projPrice= scr.nextDouble();
	System.out.println("Enter the Description");
	String projDescription=scr.next();
	
	emp.setEmpId(id);
	emp.setEmpName(name);
	emp.setSalary(salary);
	emp.setEmpDesg(designation);
	
	prj.setPrjId(projId);
	prj.setPrjName(projName);
	prj.setPrjDesp(projDescription);
	prj.setPrjPrice(projPrice);
	
	emp.setPrj(prj);
	System.out.println("the Project id is:" +emp.getPrj().getPrjId());
	System.out.println("the Project Name is:" +emp.getPrj().getPrjName());
	}
}