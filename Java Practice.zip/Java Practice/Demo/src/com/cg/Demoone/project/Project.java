package com.cg.Demoone.project;

public class Project {
	private int prjId;
	private String prjName;
	private double prjPrice;
	private String prjDesp;
	public Project(int prjId, String prjName, int prjPrice, String prjDesp) {
		super();
		this.prjId = prjId;
		this.prjName = prjName;
		this.prjPrice = prjPrice;
		this.prjDesp = prjDesp;
	}
	public Project() {
		// TODO Auto-generated constructor stub
	}
	public int getPrjId() {
		return prjId;
	}
	public void setPrjId(int prjId) {
		this.prjId = prjId;
	}
	public String getPrjName() {
		return prjName;
	}
	public void setPrjName(String prjName) {
		this.prjName = prjName;
	}
	public double getPrjPrice() {
		return prjPrice;
	}
	public void setPrjPrice(double projPrice) {
		this.prjPrice = projPrice;
	}
	public String getPrjDesp() {
		return prjDesp;
	}
	public void setPrjDesp(String prjDesp) {
		this.prjDesp = prjDesp;
	}
	@Override
	public String toString() {
		return "Project [prjId=" + prjId + ", prjName=" + prjName + ", prjPrice=" + prjPrice + ", prjDesp=" + prjDesp
				+ "]";
	}
	
	
}
