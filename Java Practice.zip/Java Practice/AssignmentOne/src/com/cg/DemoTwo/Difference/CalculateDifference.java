package com.cg.DemoTwo.Difference;

import java.util.Scanner;

public class CalculateDifference {
		public static void main(String[] args) {
			 System.out.println("Enter the Number : ");
		        Scanner sc= new Scanner(System.in);
		        int s=sc.nextInt();
		        System.out.println(calculateDifference(s));	

		}
		public static int calculateDifference(int n) {
			int individual = 0;
			int whole = 0;
			int difference = 0;
		 for (int i = 1; i<=n;i++)
		 {
			 individual += i*i;
			 whole +=i;
		 }
		whole =whole * whole;
		difference = individual - whole;
		return difference;
		}
		
}
