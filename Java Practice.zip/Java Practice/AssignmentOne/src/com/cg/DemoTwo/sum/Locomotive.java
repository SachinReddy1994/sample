package com.cg.DemoTwo.sum;
/*package com.cg.DemoTwo.sum;

import java.util.Scanner;

public class CalculateSum {

	public static void main(String[] args) {
	
        System.out.println("Enter the Number : ");
        Scanner sc= new Scanner(System.in);
        int s=sc.nextInt();
        System.out.println(calculateSum(s));
	}
	public static int calculateSum(int n)
	{
		int sum = 0;
		for(int i=0;i<=n;i++)
			if(i%3==0 || i%5==0) {
				sum += i;
			}
				return sum;
	}
}*/

public class Locomotive {
Locomotive() { main("hi"); }
public static void main(String[] args) {
System.out.print("2 ");
}
public static void main(String args) {
System.out.print("3 " + args);
}
}
