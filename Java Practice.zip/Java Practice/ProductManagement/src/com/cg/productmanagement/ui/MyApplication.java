package com.cg.productmanagement.ui;

import java.util.Scanner;

import com.cg.productmanagement.dto.ProductDetails;
import com.cg.productmanagement.servie.IProdcutService;
import com.cg.productmanagement.servie.ProductService;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    printDetails();
	    IProdcutService service=new ProductService();
	    Scanner sc=new Scanner(System.in);
		int choice=0;
	    do {
	    	ProductDetails pro=new ProductDetails();
	    	System.out.println("Enter the Choice : ");
	    	choice = sc.nextInt();
	    	switch(choice) {
	    	case 1 : // add
	    		System.out.println("Enter Id : ");
		         int id = sc.nextInt();
		 		 System.out.println("Enter Product Name : ");
		 		 String name = sc.next();
		 		 System.out.println("Enter Product Price : ");
		 		 double price = sc.nextDouble();
				 System.out.println("Enter Product Description : ");
				 String description = sc.next();
				 
				 pro.setId(id);
				 pro.setName(name);
				 pro.setPrice(price);
				 pro.setDescription(description);
				 
				 service.addProduct(pro);
				 break;	 
	    	case 2 : //show
	    		ProductDetails[] allData=service.showAllProduct();
	    		for(ProductDetails prod : allData) {
	    			if(prod!=null) {
	    				System.out.println("Product ID is : "+prod.getId());
	    				System.out.println("Product ID is : "+prod.getName());
	    				System.out.println("Product ID is : "+prod.getPrice());
	    				System.out.println("Product ID is : "+prod.getDescription());
	    			}
	    		}
	    		break;
	    	case 3 : //exit
	    		break;
	    	}
	    }while(choice!=3);
	}
			public static void printDetails() {
				System.out.println("*********");
				System.out.println("1. Add Product : ");
				System.out.println("2. Show All Product : ");
				System.out.println("3. Exit....");
			}
}
