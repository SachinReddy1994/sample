package com.cg.productmanagement.junit;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmanagement.dto.ProductDetails;
import com.cg.productmanagement.servie.IProdcutService;
import com.cg.productmanagement.servie.ProductService;

class ProductTest {
			IProdcutService service;
			ProductDetails prod;
			@BeforeEach
			public void beforeTest() {
				service = new ProductService();
				//prod = new ProductDetails();
				//prod.setId(6564);
				//prod.setName("Machine");
				//prod.setPrice(63321.64);
				//prod.setDescription("Samsung..");
			}
			@Test
			public void myTest() {
				assertNotNull(service.addProduct(prod));
			}
			@Test
			public void myTestTwo() {
				assertNotNull(service.showAllProduct());
			}
			@AfterEach
			public void afterTest() {
				service=null;
			}
}
