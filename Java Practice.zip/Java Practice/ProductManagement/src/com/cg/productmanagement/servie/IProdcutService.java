package com.cg.productmanagement.servie;

import com.cg.productmanagement.dto.ProductDetails;

public interface IProdcutService {
			public ProductDetails addProduct(ProductDetails pro);
			public ProductDetails[] showAllProduct();
}
