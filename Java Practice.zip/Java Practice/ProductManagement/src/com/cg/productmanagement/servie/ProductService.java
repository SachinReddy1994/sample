package com.cg.productmanagement.servie;

import com.cg.productmanagement.dao.IProductDao;
import com.cg.productmanagement.dao.ProductDao;
import com.cg.productmanagement.dto.ProductDetails;

public class ProductService implements IProdcutService {
			IProductDao dao;
			
			public ProductService() {
				dao= new ProductDao();
			}
	@Override
	public ProductDetails addProduct(ProductDetails pro) {
		// TODO Auto-generated method stub
		return dao.addProduct(pro);
	}

	@Override
	public ProductDetails[] showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}
				
}
