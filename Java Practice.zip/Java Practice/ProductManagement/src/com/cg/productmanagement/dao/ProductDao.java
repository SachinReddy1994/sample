package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.ProductDetails;

public class ProductDao implements IProductDao {
			
		ProductDetails prod[];
		int i=0;
		
	public ProductDao() {
			prod=new ProductDetails[5];
	}

	@Override
	public ProductDetails addProduct(ProductDetails pro) {

			prod[i] = new ProductDetails();
			prod[i].setId(pro.getId());
			prod[i].setName(pro.getName());
			prod[i].setPrice(pro.getPrice());
			prod[i].setDescription(pro.getDescription());
			i++;
			return pro;
	}

	@Override
	public ProductDetails[] showAll() {
		// TODO Auto-generated method stub
		return prod;
	}

}
