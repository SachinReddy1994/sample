package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.ProductDetails;

public interface IProductDao {
	public ProductDetails addProduct(ProductDetails pro);
	public ProductDetails[] showAll();
}
