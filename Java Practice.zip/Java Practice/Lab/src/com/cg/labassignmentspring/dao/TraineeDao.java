package com.cg.labassignmentspring.dao;

import java.util.List;

import com.cg.labassignmentspring.dto.Trainee;

public interface TraineeDao {
	public Trainee saveTrainee(Trainee trainee);

	public void removeTrainee(Trainee trainee);

	public Trainee updateTrainee(Trainee trainee);

	public Trainee findTraineeById(Integer id);

	public List<Trainee> showAllTrainee();

}
