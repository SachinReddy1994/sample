package com.cg.springcoredemo.ui;


import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.springcoredemo.config.JavaConfig;
import com.cg.springcoredemo.dto.Product;
import com.cg.springcoredemo.dto.Transaction;
import com.cg.springcoredemo.service.ProductService;
import com.cg.springcoredemo.service.ProductServiceImpl;
@Component
public class MyTest {
	
	private static ProductService service;
	@Autowired
	private ProductService productService;
	   @PostConstruct
	   private void init() {
	      service = this.productService;
	   }
	/*
	@Autowired
	ProductService service;
	static ProductService productService;
	 @PostConstruct
	   private void init() {
	      service = this.productService;
	   }*/
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class);
		Product myProduct= (Product) app.getBean("product");
		Transaction myTransaction=(Transaction) app.getBean("transaction");
		myProduct.setId(1001);
		myProduct.setName("ABCD");
		myProduct.setPrice(100100);
		myProduct.setDescription("Godd");
		
		myTransaction.setId(10);
		myTransaction.setPrice(11412);
		myTransaction.setDescription("coooool");
		
		service.addProduct(myProduct);
		System.out.println(service.showAllProduct());
	
	}

}
