package com.cg.springcoredemo.service;

import java.util.List;

import com.cg.springcoredemo.dto.Product;

public interface ProductService {
		public void addProduct(Product prod);
		public List<Product> showAllProduct();
}