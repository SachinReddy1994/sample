package com.cg.springcoredemo.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.springcoredemo.dto.Product;
import com.cg.springcoredemo.dto.Transaction;
import com.cg.springcoredemo.service.ProductService;

@Configuration
@ComponentScan("com.cg.springcoredemo")
public class JavaConfig {
		
	

	
	/*@Bean(name="prod",autowire=Autowire.BY_TYPE)
		public Product getProduct() {
			Product pro = new Product();
			pro.setId(4100);
			pro.setName("sss");
			pro.setPrice(52582.141);
			pro.setDescription("best");
			return pro;
		}
	@Bean(name="tran")
	public Transaction geTransaction() {
		Transaction t=new Transaction();
		t.setId(101);
		t.setPrice(2525252);
		t.setDescription("too costlyyyyyyy for produc 1");
		
		return t;
	}*/
}
