package com.cg.springmvcdemoone.dao;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface ProductDao{
		public Product save(Product pro);
		public List<Product> show();
}
