package com.cg.springmvcdemoone.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemoone.dto.Product;
@Repository
public class ProductDaoImp implements ProductDao {

	
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		entitymanager.persist(pro);
		entitymanager.flush();
		return pro;
	}

	@Override
	public List<Product> show() {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM Product");
		List<Product> myList=query.getResultList();
		
		return myList;
	}

}
