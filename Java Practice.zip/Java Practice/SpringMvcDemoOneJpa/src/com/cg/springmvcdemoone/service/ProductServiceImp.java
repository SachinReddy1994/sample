package com.cg.springmvcdemoone.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.ProductDao;
import com.cg.springmvcdemoone.dto.Product;
@Service
@Transactional
public class ProductServiceImp implements ProductService {
		
	@Autowired
	ProductDao productdao;

	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productdao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productdao.show();
	}
}
