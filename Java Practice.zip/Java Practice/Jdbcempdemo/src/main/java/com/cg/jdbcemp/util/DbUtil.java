package com.cg.jdbcemp.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.jdbcemp.exception.EmployeeException;


public class DbUtil {
		static Connection conn;
		
		public static Connection getConnection() throws EmployeeException {
			Properties prop = new Properties();
		
			try {
				InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
				prop.load(it);
				
			
					if(prop!=null) {
				String driver = prop.getProperty("jdbc.driver");
				String url = prop.getProperty("jdbc.url");
				String uname = prop.getProperty("jdbc.username");
				String upass = prop.getProperty("jdbc.password");
				Class.forName(driver);
				conn=  DriverManager.getConnection(url, uname, upass);
				}
			
			} catch (FileNotFoundException e  ) {
				e.printStackTrace();
				throw new EmployeeException("File not Found");
			}
			catch (ClassNotFoundException |SQLException |IOException e ) {
				e.printStackTrace();
				throw new EmployeeException("");
			} 
			return conn;
			
		}
}
