package com.cg.jdbcemp.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.jdbcemp.dto.Employee;
import com.cg.jdbcemp.exception.EmployeeException;

public interface EmployeeDao {
		public Employee save(Employee emp) throws EmployeeException;
		public List<Employee> findBy(String Name);
		public Employee findbyId(int id) throws EmployeeException;
		public List<Employee> showAll() throws  EmployeeException ;
}
