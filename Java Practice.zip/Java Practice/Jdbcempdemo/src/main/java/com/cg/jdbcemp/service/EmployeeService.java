package com.cg.jdbcemp.service;
import java.util.List;
import com.cg.jdbcemp.dto.Employee;
import com.cg.jdbcemp.exception.EmployeeException;
public interface EmployeeService {
		public void addEmployee(Employee emp);
		public List<Employee> searchbyName(String name);
		public Employee searchbyId(int id) throws EmployeeException;
		public List<Employee> showAll() throws EmployeeException;
		public Employee update(Employee emp);
		public void sort();
}
