package com.cg.jdbcemp.exception;

public class EmployeeException extends Exception{
	public EmployeeException() {
		// TODO Auto-generated constructor stub 
		super();
	}
	public EmployeeException(String msg) {
		super(msg);
	}
}
