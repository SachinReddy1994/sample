package com.cg.jdbcemp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.jdbcemp.dto.Employee;
import com.cg.jdbcemp.exception.EmployeeException;
import com.cg.jdbcemp.util.DbUtil;




public class EmployeeDaoImp implements EmployeeDao{
	PreparedStatement pstm;
	public Employee save(Employee emp) throws EmployeeException {
		 Connection con = DbUtil.getConnection();
		String query_insert = "INSERT INTO employee VALUES(?,?,?)";
		try { pstm = con.prepareStatement(query_insert);
		pstm.setInt(1, emp.getId());
		pstm.setString(2, emp.getName());
		pstm.setDouble(3, emp.getSalary());
		
		pstm.executeUpdate();
	}catch(SQLException e) {
		e.printStackTrace();
	}finally {
		try {
			pstm.close();
			con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	} return null;
	}

	public List<Employee> findBy(String Name) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee findbyId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Employee> showAll() throws EmployeeException {
		Connection con = DbUtil.getConnection();
		String query_show="SELECT * FROM employee ";
		
		List<Employee> myList = new ArrayList<Employee>();
		try {
			pstm=con.prepareStatement(query_show);
		ResultSet result = null;	
			result = pstm.executeQuery();
			while(result.next()) {
				Employee emp = new Employee();
				emp.setId(result.getInt("emp_id"));
				emp.setName(result.getString("emp_name"));
				emp.setSalary(result.getInt("emp_salary"));
					myList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Show not working");
		}finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return myList;
	}
	
}