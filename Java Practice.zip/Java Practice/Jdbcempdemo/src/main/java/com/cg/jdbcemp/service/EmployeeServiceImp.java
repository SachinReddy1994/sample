package com.cg.jdbcemp.service;

import java.util.List;

import com.cg.jdbcemp.dao.EmployeeDao;
import com.cg.jdbcemp.dao.EmployeeDaoImp;
import com.cg.jdbcemp.dto.Employee;
import com.cg.jdbcemp.exception.EmployeeException;

public class EmployeeServiceImp implements EmployeeService{
			EmployeeDao dao;
	public EmployeeServiceImp() {
		dao= new EmployeeDaoImp();
	}
	

	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		emp.setSalary(emp.getSalary()+(emp.getSalary()*10/100));
		try {
			dao.save(emp);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Employee> searchbyName(String name) {
		// TODO Auto-generated method stub
		return dao.findBy(name);
	}


	public Employee searchbyId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.findbyId(id);
	}

	public List<Employee> showAll() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	public Employee update(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	public void sort() {
		// TODO Auto-generated method stub
		
	}

}
