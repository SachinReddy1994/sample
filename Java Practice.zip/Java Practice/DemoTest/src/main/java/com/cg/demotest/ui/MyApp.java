package com.cg.demotest.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class MyApp {
		public static void main(String[] args) 
		{
			
		/*Employee emp = new Employee(10001,"sasa",64945.5);
	
	
		try {
			OutputStream fWrite = new FileOutputStream("D:\\obj.txt");
			ObjectOutput objWrite = new ObjectOutputStream(fWrite); 
			objWrite.writeObject(emp);
			objWrite.flush();
			objWrite.close();
		
		} catch (FileNotFoundException e) {
				System.out.println("File Not Found");
		}	catch(IOException e) {
			System.out.println("File not write/open");
		}
	
			Employee empRead = null;
		try {

			FileInputStream fRead = new FileInputStream("D:\\obj.txt");
			ObjectInputStream objRead = new ObjectInputStream(fRead);
			empRead = (Employee) objRead.readObject();
			objRead.close();
			System.out.println(empRead);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/

			
			
			/*String str = "Cap Gemini";
			System.out.println(str);
			StringBuffer st = new StringBuffer();
			StringBuilder st1 = new StringBuilder();
			StringTokenizer str1= new StringTokenizer("Capgemini..,.......");
			while(str1.hasMoreTokens()) {
			System.out.println(str1.nextToken(","));
			}*/
			
			
			Reader read = null;
			Writer write = null;
			BufferedReader bufRead = null;
			BufferedWriter bufWrite = null;
			
			try {
				read = new FileReader("myread.txt");
				bufRead =  new BufferedReader(read);
				write = new FileWriter("mywrite.txt");
				bufWrite = new BufferedWriter(write);
				String data=null,line;
						while((data=bufRead.readLine())!=null) {
							//data = data.replaceAll("\\s", "");
							if(data.contains(":")) {
							StringTokenizer st=new StringTokenizer(data, ":");
							st.nextToken(":");
							String s=st.nextToken(":");
							bufWrite.write(s);	
							bufWrite.newLine();
							}
							else
								bufWrite.newLine();
							
				}
			}
				 catch (FileNotFoundException e) {
				System.out.println("File Not Found.....");
			} catch (IOException e) {
				System.out.println("File can't read/write");
			}finally {
					try {
						bufRead.close();
						bufWrite.close();
					}catch (IOException e){
						System.out.println("File Not Close");
					}
			}
		}
	}
