package com.cg.demotwo.exceptin;

public class Exceptin {

	public static void main(String[] args) {
		try {
			new Bone().getAll();
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Check Your Array");
		}finally {
			System.out.println("Error found");
		}
	}

}
