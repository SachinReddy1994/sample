package com.cg.demotwo.exceptin;

public class Bone {
			public void getAll() throws ArrayIndexOutOfBoundsException{
				/*int a[] = {45,6,8,9};
				try {
					System.out.println("The array is :"+a[6]);
				}catch(NullPointerException e) {
					System.out.println("Check array.....");
				}catch(ArrayIndexOutOfBoundsException f) {
					System.out.println("Cechhch");
				}
				finally {
				
					System.out.println("It will execute always....");
				}*/
				
			  int a = 10 ;
			  int b = 0;
			  if(b==0) {
				  throw new ArithmeticException();
			  }
			    System.out.println("Result .."+a/b);
			}
}
