package com.cg.demotwo.oops;

public class Ploymor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			/*Aa temp=(Aa)new Bb();
			((Aa)temp).getAll();
			System.out.println(temp.a);
	}
}

class Bb{
		static int a=10;
	public void getAll() {
		 System.out.println("Hi B ...");
	}
}
 class Aa extends Bb{
	 int a = 20;
	 public void getAll() {
		 super.getAll();
	 System.out.println("Hi A ...");*/
      Abstrat temp = new DayShift();// this type of concept is runtime polymorphism
      temp.logIn();
      temp.logOut();
      temp.getCompany();
      System.out.println(temp.timing);
	}
	}
