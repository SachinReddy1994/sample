package com.cg.demotwo.oops;

public abstract class Abstrat {
		double timing = 9.5;
		public abstract void logIn();
		public abstract double logOut();
		
		public String getCompany() {
			return "CapGemini";
		}
	}


