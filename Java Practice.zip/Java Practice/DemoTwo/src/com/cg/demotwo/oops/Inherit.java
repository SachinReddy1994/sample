package com.cg.demotwo.oops;

public class Inherit {
public static void main(String[] args) {
	B temp = new B();
	System.out.println(temp.a);
	((A) temp).getAll();
}
}

class A{
	int a=10;
	public A() {
		System.out.println("In class A.....");
	}
	public void getAll() {
		System.out.println("In Class A Methods...");
	}
}

class B extends A{
	public B() {
		System.out.println("In class B...");
	/*int i=12;
	int j=2;
	try {
	int result = i/(j-2);
	System.out.println(result);
	} catch (Exception e) {
		System.out.println("Error: "+e.getMessage());
e.printStackTrace();
	}*/
}
}