package com.cg.demotwo.oops;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/*abstract class Aaa{
	static {
	System.out.println("In A...");
	}
	static int x=50;
}*/
 class B  {
	public static void main(String[] args) {		
			ZonedDateTime zone = ZonedDateTime.now(ZoneId.of("America/Los_Angeles"));
			System.out.println(zone);
		
		//LocalTime local = LocalTime.now();
			//System.out.println(local.isLeapYear());
			//System.out.println(local);

		/*System.out.println("IN Main......");
		 System.out.println(Aaa.x=55);
		Class.forName("com.cg.demotwo.oops.Aaa");
	}
				//static {
				System.out.println("In A...");
	}*/
		/*Date date= new Date();
		Scanner sc= new Scanner(System.in);
		int s = sc.nextInt();
		System.out.println(s);
		System.out.println(date.getTime());
		System.out.println(date.getDate());*/
	
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Date ");
		String date = sc.next();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date givenDate = dateFormat.parse(date);
		System.out.println(givenDate.getDate());*/
		}
 }
