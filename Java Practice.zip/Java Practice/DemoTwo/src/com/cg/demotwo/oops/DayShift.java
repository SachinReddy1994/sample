package com.cg.demotwo.oops;

public class DayShift extends Abstrat{

	@Override
	public void logIn() {
		// TODO Auto-generated method stub
		System.out.println("Hi Login Succes");
	}

	@Override
	public double logOut() {
		// TODO Auto-generated method stub
		return 9.5;
	}

}
