package com.cg.demotwo.ui;

import java.math.BigDecimal;

import com.cg.demotwo.ui.A.B;

public class MyTest {
	static double salary = 1000;
	public static void main(String[] args) {
	//B temp = 	new A().new B();  non static
		B temp=new A.B();
		temp.getAll();
		
		A demo = new A();
		demo.get();
	}
}	

 class A {
	 private static int a = 10;
	 	static class B{
		 int b = 20;
		 public void getAll() {
			 System.out.println("In class B"+a);
		 		 }
	 }
	 public void get() {
		 System.out.println("In  Class A...");
	 }
 }
		
		
		
		
		
		
		
		
		
		/*System.out.println("In Main.......");
		 MyTest test = new MyTest();
		 getAllData();
		 test.getData();
		Employee.pf=1200;
		Employee emp = new Employee(1001,"asasd",new BigDecimal(10000),0.1);
		System.out.println(emp.getEmpId());
		System.out.println(emp.takeHomeSalary());
		System.out.println(emp.getFullName());
		
		System.out.println("Pf is  :" +Employee.pf);
		Employee empOne = new Employee(1002,"adff",new BigDecimal(12000),0.2);
		
		System.out.println(empOne.getEmpId());
		System.out.println(empOne.takeHomeSalary());
		System.out.println(empOne.getFullName());
		
	
static void getAllData() {
	//static
	System.out.println("Static...");
}
   void getData() {
	   // Non Static
	   System.out.println("Non Static");
   } 
		 new A();
		 new A();
A.getAll();
}
static {
	System.out.println("Hi in Static Block");
}
}
class A{
	static {
		System.out.println("In A static BLock");
			}


public static void getAll() {
	// TODO Auto-generated method stub
	System.out.println("This Static Method");*/