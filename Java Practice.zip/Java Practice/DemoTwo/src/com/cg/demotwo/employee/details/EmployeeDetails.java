package com.cg.demotwo.employee.details;

import java.util.Scanner;

import com.cg.demotwo.employee.details.dto.Employee;

public class EmployeeDetails {

	private static double[] Salary;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Employee[] emp = new Employee[10];	
			int option = 0,i=0;
			Scanner sc=new Scanner(System.in);
			do 
			{ 
				System.out.println(" 1.Add Employee\n 2.Show Employee\n 3.Exit");
				System.out.println("Enter Choice : ");
				option = sc.nextInt();
				sc.nextLine();
				switch(option) {
				case 1 :
						 System.out.println("Enter the Employee Id : ");
				         int id = sc.nextInt();
				 		 System.out.println("Enter the Employee Name : ");
				 		 String name = sc.next();
				 		 System.out.println("Enter the Employee Salary : ");
				 		 double salary = sc.nextDouble();
						 System.out.println("Enter the Employee Designation : ");
						 String designation = sc.next();
						 
						 
						 emp[i]=new Employee();
						 emp[i].setEmpId(id);
						 emp[i].setEmpName(name);
						 emp[i].setEmpSalary(salary);
						 emp[i].setEmpDesignation(designation);
						 i++;
						 break;	 

				case 2 :   for( i = 0; emp[i]!=null; i++) {
						  System.out.println("EmpId : "+emp[i].getEmpId());
						  System.out.println("EmpName : " +emp[i].getEmpName());
						  System.out.println("EmpSalary : " +emp[i].getEmpSalary());
						  System.out.println("EmpDesignation : "+emp[i].getEmpDesignation());
							}
				break;
				
				case 3 : System.out.println("Exit ");
							break;
				
				default : System.out.println("Invalid Choice");
							break;
				}
			}while(option!=3);
		}

       }

	


