package com.cg.tread;

public class myRunner implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++) {
			System.out.println(i);
		/* if(i==5) {
			 throw new NullPointerException();
		 }*/
		}
	}
				
}
