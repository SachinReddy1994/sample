package com.cg.tread;

public class Tread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
					Thread t = new Thread(new myRunner());
					t.start();
					System.out.println("Start to finish");
	}

}
