package com.cg.jpademo.dao;

import java.util.List;

import com.cg.jpademo.dto.Employee;

public interface EmployeeDao {
	public void save(Employee emp);
	public List<Employee> findBySalary(double low,double higher);
	public List<Employee> findByDepartmentName(String name);
}
