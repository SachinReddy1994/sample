package com.cg.jpademo.dto;

import java.time.zone.ZoneOffsetTransitionRule.TimeDefinition;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="employeedb")
public class Employee {
		@Id
		@Column(name="emp_id")
		private int id;
		@Column(name="emp_name")
		private String name;
		@Column(name="emp_salary")
		private double salary;
		@Column(name="emp_type")
		private boolean type;
		@Column(name="joining")
		//@Temporal(TemporalType.DATE)
		private Date dateofJoining;
		@Embedded
		private Address addr;
		@ManyToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="dep_id")
		private Department dep;
		public Employee() {
	}
		
		public Employee(int id, String name, double salary, boolean type, Date dateofJoining, Address addr,
				Department dep) {
			super();
			this.id = id;
			this.name = name;
			this.salary = salary;
			this.type = type;
			this.dateofJoining = dateofJoining;
			this.addr = addr;
			this.dep = dep;
		}


		public Address getAddr() {
			return addr;
		}

		public void setAddr(Address addr) {
			this.addr = addr;
		}


		public Date getDateofJoining() {
			return dateofJoining;
		}

		public void setDateofJoining(Date dateofJoining) {
			this.dateofJoining = dateofJoining;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public double getSalary() {
			return salary;
		}

		public void setSalary(double salary) {
			this.salary = salary;
		}

		public boolean isType() {
			return type;
		}

		public void setType(boolean type) {
			this.type = type;
		}


		public Department getDep() {
			return dep;
		}


		public void setDep(Department dep) {
			this.dep = dep;
		}


		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type
					+ ", dateofJoining=" + dateofJoining + ", addr=" + addr + ", dep=" + dep + "]";
		}




		
}
