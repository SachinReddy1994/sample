package com.cg.jpademo.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.Basic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.apache.log4j.BasicConfigurator;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.dto.EmployeeService;
import com.cg.jpademo.service.EmployeeServiceImpl;

public class MainJPA {
		public static void main(String[] args) { 
			EmployeeServiceImpl service = new EmployeeServiceImpl();
			Scanner sc=new Scanner(System.in);
						System.out.println("Enter Employee Id : ");			
						int id=sc.nextInt();
			System.out.println("Enter Employee name");
			String name = sc.next();
			System.out.println("Enter Salary");
		Double salary = sc.nextDouble();
		System.out.println("Enter Date of Joining :  ");
		String date = sc.next();
		System.out.println("Enter Department Id");			
		int depId=sc.nextInt();
			System.out.println("Enter Department Name : ");
			String depName=sc.next();			
			Department dep = new Department();
	dep.setId(depId);
		dep.setName(depName);
		
		Employee emp = new Employee();
			emp.setId(id);
		emp.setName(name);
			emp.setSalary(salary);
		emp.setAddr(new Address("pune","mh",78090));
		emp.setDateofJoining(new Date());
		emp.setDep(dep);
			
			
			service.addEmployee(emp);
			/*List<Employee> myList = service.searchBySalary(2000, 10000);
			for (Employee employee : myList) {
				System.out.println("Employee Id"+employee.getId());
				System.out.println("Employee Name "+employee.getName());
				System.out.println("Employee Salary"+employee.getSalary());
				System.out.println("Employee Department"+employee.getDep().getName());
			}
			List<Employee> myListOne = service.searchByDepartmentName("dfDF");
			for (Employee employee : myListOne) {
				System.out.println("Employee Name -----"+employee.getName());
				System.out.println("Employee Department"+employee.getDep().getName());
			}*/
			
			//BasicConfigurator.configure();
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("demoemployeemanagement");
			EntityManager em = emf.createEntityManager();
			EntityTransaction tx = em.getTransaction();
			/*EmployeeService service = new EmployeeService();
			Department dep = new Department();
			dep.setId(101);
			dep.setName(".Net");
			
			Department depOne = new Department();
			depOne.setId(201);
			depOne.setName("Java");
			
			Address addr = new Address();
			addr.setCity("Pune");
			addr.setState("MAharastra");
			addr.setPincode(654561);
			
			Employee emp = new Employee();
			emp.setId(101);
			emp.setName("SSSS");
			emp.setSalary(561430.25);
			emp.setType(true);
			emp.setAddr(addr);
			emp.setDateofJoining(new Date());
			emp.setDep(dep);
			
			Employee empOne = new Employee();
			empOne.setId(201);
			empOne.setName("ggSS");
			empOne.setSalary(5430.25);
			empOne.setType(true);
			empOne.setAddr(addr);
			empOne.setDep(depOne);
			empOne.setDateofJoining(new Date());
			
			Employee empTwo = new Employee();
			empTwo.setId(301);
			empTwo.setName("efSS");
			empTwo.setSalary(61430.25);
			empTwo.setType(true);
			empTwo.setAddr(addr);
			empTwo.setDep(dep);
			empTwo.setDateofJoining(new Date());
			
			List<Employee> myList = new ArrayList<Employee>();
			myList.add(emp);
			myList.add(empOne);
			myList.add(empTwo);
			dep.getMyEmployeeList().add(emp);
			dep.getMyEmployeeList().add(empOne);
			dep.getMyEmployeeList().add(empTwo);
			*/
			tx.begin();
			em.persist(emp);
			em.persist(dep);
			tx.commit();
		
			
			//Employee employeedb = service.createEmployee(12, "ugssdda", 951586.51, true,new Date(),new Address("Pune", "Maharastra", 541644));
			//System.out.println("Employee Persisted : " + employeedb);
		
			/*employeedb = service.FindEmployee(1);
			System.out.println("Employee Found : "+employeedb);
			
			employeedb = service.updateEmployee(2,500000);
			System.out.println("Employee Updated : "+employeedb);
			
			service.removeEmployee(3);
			System.out.println("Employee Removed");
			
			employeedb = service.FindEmployee(3);
			System.out.println("Employee Not Found : "+employeedb);*/
		}
}
