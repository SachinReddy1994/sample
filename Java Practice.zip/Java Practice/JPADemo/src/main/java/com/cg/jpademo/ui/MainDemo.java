package com.cg.jpademo.ui;

import java.util.Date;

import javax.persistence.Basic;

import org.apache.log4j.BasicConfigurator;

import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.dto.EmployeeService;

public class MainDemo {
		public static void main(String[] args) { 
			//BasicConfigurator.configure();
			EmployeeService service = new EmployeeService();
			Employee employeedb = service.createEmployee(6, "Sussa", 95156.0251, true,new Date(), null);
			System.out.println("Book Persisted : " + employeedb);
		
			employeedb = service.FindEmployee(1);
			System.out.println("Employee Found : "+employeedb);
			
			employeedb = service.updateEmployee(2,500000);
			System.out.println("Employee Updated : "+employeedb);
			
			service.removeEmployee(3);
			System.out.println("Employee Removed");
			
			employeedb = service.FindEmployee(3);
			System.out.println("Employee Not Found : "+employeedb);
		}
}
