package com.cg.springcoredemo.dto;

public class Item {
	private int id;
	private String shopName;
	
	public Item() {
		//System.out.println(" Itemmmmmm");
		}
	
	public Item(int id, String shopName) {
		super();
		this.id = id;
		this.shopName = shopName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public void getData() {
		System.out.println("hyyyyyy");
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", shopName=" + shopName + "]";
	}
}
