package com.cg.springcoredemo.dto;

import java.util.List;

public class Product {
		private int id;
		private String name;
		private double price;
		private String description;
		
		//private Item it;
		private List<Item> it;

		public Product(int id, String name, double price, String description, List<Item> it) {
			super();
			this.id = id;
			this.name = name;
			this.price = price;
			this.description = description;
			this.it = it;
		}

		public Product() {
			// TODO Auto-generated constructor stub
			System.out.println("Prrrrrr");
		}
		
		public void getAllData() {
			System.out.println("Id is : "+id);
			System.out.println("Name is : "+name);
			System.out.println("Price is : "+price);
			System.out.println("Description is : "+description);
			for (Item item : it) {
				System.out.println("Item id is : "+item.getId());
				System.out.println("Shop Name is : "+item.getShopName());
			}
			/*System.out.println("Item id is : "+it.getId());
			System.out.println("Shop Name is : "+it.getShopName());*/
		}



		

/*		public Item getIt() {
			return it;
		}

		public void setIt(Item it) {
			this.it = it;
		}*/

/*		public Product(int id, String name, double price, String description, Item it) {
			super();
			this.id = id;
			this.name = name;
			this.price = price;
			this.description = description;
		//	this.it = it;
		}*/

		public int getId() {
			return id;
		}

		public List<Item> getIt() {
			return it;
		}

		public void setIt(List<Item> it) {
			this.it = it;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		@Override
		public String toString() {
			return "Product [id=" + id + ", name=" + name + ", price=" + price + ", description=" + description
					+ ", it=" + it + "]";
		}

		/*@Override
		public String toString() {
			return "Product [id=" + id + ", name=" + name + ", price=" + price + ", description=" + description + "]";
		}*/
		
		
}
