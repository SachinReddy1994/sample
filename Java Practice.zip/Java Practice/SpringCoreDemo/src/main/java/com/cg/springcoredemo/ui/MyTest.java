package com.cg.springcoredemo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springcoredemo.dto.Item;
import com.cg.springcoredemo.dto.Product;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext app=new ClassPathXmlApplicationContext("Spring.xml");
		
		Product p=(Product) app.getBean("prod");
/*		p.setId(100);
		p.setName("sac");
		p.setPrice(25.52);
		p.setDescription("dgsgsgrdrg");*/
		p.getAllData();

		//Item i=(Item) app.getBean("it");
		//i.getData();
	}

}
