package com.cg.ProductSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.ProductSpringBoot.dto.Product;

public interface ProductDao extends JpaRepository<Product, Integer>{
/*	public Product save(Product pro);
	public List<Product> showAll();
	public Product search(int id);
	public Product delete(Product prod);*/
	List<Product> findByName(String name);
	//@Query
	List<Product> findByPriceBetween(double low, double high);
}
