package com.cg.ProductSpringBoot.service;

import java.util.List;

import com.cg.ProductSpringBoot.dto.Product;

public interface ProductService {
			public Product addProduct(Product pro);
			public List<Product> showAll();
			List<Product> search(String name);
			List<Product> findByPriceBetween(double low, double high);
			/*public Product search(int id);
			public Product delete(Product prod);*/
			//public Product search(String name);
}
