package com.cg.ProductSpringBoot.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="product_boot")
public class Product {
		@Id
		@Column(name="prod_id")
		private int id;
		@Column(name="prod_name")
		private String name;
		@Column(name="prod_price")
		private double price;
		@Column(name="prod_desc")
		private String desc;
		
		@OneToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="inventory")
		private Inventory inventory;
		public Product() {
			// TODO Auto-generated constructor stub
		}

		public Product(int id, String name, double price, String desc) {
			super();
			this.id = id;
			this.name = name;
			this.price = price;
			this.desc = desc;
		}

		public Inventory getInventory() {
			return inventory;
		}

		public void setInventory(Inventory inventory) {
			this.inventory = inventory;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public String getDesc() {
			return desc;
		}

		public void setDesc(String desc) {
			this.desc = desc;
		}

		@Override
		public String toString() {
			return "Product [id=" + id + ", name=" + name + ", price=" + price + ", desc=" + desc + ", inventory="
					+ inventory + "]";
		}

		public Product(int id, String name, double price, String desc, Inventory inventory) {
			super();
			this.id = id;
			this.name = name;
			this.price = price;
			this.desc = desc;
			this.inventory = inventory;
		}

	}
