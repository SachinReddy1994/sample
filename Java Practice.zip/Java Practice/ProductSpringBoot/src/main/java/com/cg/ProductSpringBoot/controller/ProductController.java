package com.cg.ProductSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductSpringBoot.dto.Inventory;
import com.cg.ProductSpringBoot.dto.Product;
import com.cg.ProductSpringBoot.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
	@Autowired
	ProductService productService;
/*	//@GetMapping("/checkname")
	//@RequestMapping(name="/checkname",method=RequestMethod.GET)
	@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	public String getName(@PathVariable("uname") String yname,
			@RequestParam("prodid") String id) {
		System.out.println("uuuu");
		return id+ " hai " +yname;
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("prodid") int pid,
			@RequestParam("prodname") String pname,@RequestParam("prodprice") String pprice) {
		System.out.println(pid+ " " +pname+ " " +pprice);
		return "Welcome" +pid+ " " +pname+ " " +pprice;
	}*/
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	//@CrossOrigin(origins= {"http://localhost:4200","http://localhost:9098"})
	//@CrossOrigin(origins="http://localhost:4200",allowCredentials="true",allowedHeaders="*")
	//@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {
		//productService.addProduct(pro);
		Product prod=productService.addProduct(pro);
		if(prod==null) {
			return new ResponseEntity("Product Not Added",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
	}
	
	@RequestMapping(value="/show",method=RequestMethod.GET)
	//@CrossOrigin(origins= {"http://localhost:4200","http://localhost:9098"})
	//@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> myList=productService.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("Np Product to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
	}
	
	@RequestMapping(value="/price",method=RequestMethod.POST)
	//@CrossOrigin(origins= {"http://localhost:4200","http://localhost:9098"})
	//@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Product>> search(@RequestParam("low") double lowprice,
			@RequestParam("high") double highprice){
		/*double low=Double.parseDouble(lowprice);
		double high=Double.parseDouble(highprice);*/
		List<Product> myList=productService.findByPriceBetween(lowprice,highprice);
		if(myList.isEmpty()) {
			return new ResponseEntity("Np Product to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
	}
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	//@CrossOrigin(origins="http://localhost:4200")
	//@CrossOrigin(origins= {"http://localhost:4200","http://localhost:9098"})
	//public ResponseEntity<Product> addall(@RequestBody Product prod){
		public ResponseEntity<Product> addall(@ModelAttribute Product prod){
	/*public ResponseEntity<Product> addall(@RequestParam("id") int pid,
			@RequestParam("name") String pname,
			@RequestParam("price") double price,
			@RequestParam("desc") String desc,
			@RequestParam("inid") int inid,
			@RequestParam("inname") String inname){
		Inventory inventory = new Inventory();
		inventory.setId(inid);
		inventory.setName(inname);
		
		Product prod=new Product();
		prod.setId(pid);
		prod.setName(pname);
		prod.setPrice(price);
		prod.setDesc(desc);
		prod.setInventory(inventory);*/
		
		Product pro=productService.addProduct(prod);
		
		if(pro==null) {
			return new ResponseEntity("Np Product to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(pro,HttpStatus.OK);
	}

	
		@RequestMapping(value="/search",method=RequestMethod.GET)
	public List<Product> search(@RequestParam("pname") String name) {
		return productService.search(name);
	}
	
	/*@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Product update(@RequestBody Product product){
		
		Product prod  = productService.search(product.getId()); 
		prod.setPrice(product.getPrice());
		prod.setName(product.getName());
		prod.setDesc(product.getDesc());
		return prod;
	}
	@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	public Product delete(@RequestParam("prodId") String id){
		
		int pid = Integer.parseInt(id);
		Product prod  = productService.search(pid);
		return productService.delete(prod); 
	}*/
}
