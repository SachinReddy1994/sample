package com.cg.demomvcjavaconfig.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Transaction;

@Repository
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext
	EntityManager entitymanager;
	//List<Product> myList=new ArrayList<>();
	@Override
	public Product save(Product pro) {
		// TODO Auto-generated method stub
		Product prodOne=getProduct(pro.getId());
		System.out.println(prodOne);
		if(prodOne==null) {
		entitymanager.persist(pro);
		entitymanager.flush();
		
		}else {
			Transaction tran=new Transaction();
			tran.setId(pro.getTran().get(0).getId());
			tran.setPro(pro);
			entitymanager.persist(tran);
			entitymanager.flush();
		}
		return pro;
	}

	@Override
	public List<Product> show() {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM Product");
		List<Product> myList=query.getResultList();
		return myList;
	}
	
	public Product getProduct(Integer prodId) {
		Product pro=null;
		try {
		Query query=entitymanager.createQuery("FROM Product WHERE id=:prodId");
		query.setParameter("prodId", prodId);
		pro=(Product) query.getSingleResult();
		
	}catch(NoResultException ex) {
		System.out.println("No id found");
	}
		
		return pro;
}		
}
