package com.cg.demohash.dto;

public class Person{
	private String name;
	private static int count=0;
	public Person() {
		// TODO Auto-generated constructor stub
	}


	public Person(String name) {
		super();
		this.name = name;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Person [name=" + name + "]";
	}


	@Override
	public boolean equals(Object obj) {
			System.out.println("Equals .....");
			setCount(getCount() + 1);
			return (this.getName().equals(((Person)obj).getName()));
	}
	
	@Override
	public int hashCode() {
			return 10;
		   //return name.charAt(0);
			//return name.hashCode();
	}

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		Person.count = count;
	}
}
