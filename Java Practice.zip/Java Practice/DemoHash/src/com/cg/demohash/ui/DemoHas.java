package com.cg.demohash.ui;

import java.util.HashSet;
import java.util.Set;

import com.cg.demohash.dto.Person;

public class DemoHas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person pOne = new Person("Sachin");
		Person pTwo = new Person("Virat");
		Person pThree = new Person("Dhoni");
		Person pFour= new Person("Sehwag");
		Person pFive= new Person("Ganguly");
		Person pSix= new Person("Yuvraj");
		Person pSeven= new Person("Azar");
		Person pEight= new Person("Bhuvaneshwar");
		Person pNine= new Person("Rohit");
		Person pTen= new Person("Lakshman");

		
		  Set<Person> personList = new HashSet<Person>();
		  personList.add(pOne);
		  personList.add(pTwo);
		  personList.add(pThree);
		  personList.add(pFour);
		  personList.add(pFive);
		  personList.add(pSix);
		  personList.add(pSeven);
		  personList.add(pEight);
		  personList.add(pNine);
		  personList.add(pTen);
		  System.out.println(Person.getCount());
		  
	}

}
